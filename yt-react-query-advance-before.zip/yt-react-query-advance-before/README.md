### Welcome to React query advance.

1. Paginated queries
2. Parallel queries
3. Optimistic updates
4. Dependant queries

### json server

`json-server --watch db.json`
